﻿namespace Login_Vilm.kom
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            this.pnlLoginMain = new System.Windows.Forms.TableLayoutPanel();
            this.pnlLoginSecundary = new System.Windows.Forms.TableLayoutPanel();
            this.pnlLoginTitel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlLoginTitel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLoginTitel2 = new System.Windows.Forms.Label();
            this.pnlLoginInfo = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlEmail = new System.Windows.Forms.TableLayoutPanel();
            this.txtGebruikersnaam = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlWachtwoord = new System.Windows.Forms.TableLayoutPanel();
            this.txtWachtwoord = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlButton = new System.Windows.Forms.TableLayoutPanel();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblErrorMessage = new System.Windows.Forms.Label();
            this.pnlLoginMain.SuspendLayout();
            this.pnlLoginSecundary.SuspendLayout();
            this.pnlLoginTitel1.SuspendLayout();
            this.pnlLoginTitel2.SuspendLayout();
            this.pnlLoginInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlEmail.SuspendLayout();
            this.pnlWachtwoord.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLoginMain
            // 
            this.pnlLoginMain.BackColor = System.Drawing.Color.Black;
            this.pnlLoginMain.ColumnCount = 3;
            this.pnlLoginMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.pnlLoginMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.pnlLoginMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.pnlLoginMain.Controls.Add(this.pnlLoginSecundary, 1, 1);
            this.pnlLoginMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLoginMain.Location = new System.Drawing.Point(0, 0);
            this.pnlLoginMain.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLoginMain.Name = "pnlLoginMain";
            this.pnlLoginMain.RowCount = 3;
            this.pnlLoginMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.93901F));
            this.pnlLoginMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.99323F));
            this.pnlLoginMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.pnlLoginMain.Size = new System.Drawing.Size(1426, 839);
            this.pnlLoginMain.TabIndex = 3;
            // 
            // pnlLoginSecundary
            // 
            this.pnlLoginSecundary.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlLoginSecundary.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.pnlLoginSecundary.ColumnCount = 1;
            this.pnlLoginSecundary.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlLoginSecundary.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.pnlLoginSecundary.Controls.Add(this.pnlLoginTitel1, 0, 0);
            this.pnlLoginSecundary.Controls.Add(this.pnlLoginInfo, 0, 1);
            this.pnlLoginSecundary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLoginSecundary.Location = new System.Drawing.Point(477, 93);
            this.pnlLoginSecundary.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLoginSecundary.Name = "pnlLoginSecundary";
            this.pnlLoginSecundary.RowCount = 2;
            this.pnlLoginSecundary.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.86834F));
            this.pnlLoginSecundary.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 82.13166F));
            this.pnlLoginSecundary.Size = new System.Drawing.Size(471, 659);
            this.pnlLoginSecundary.TabIndex = 0;
            // 
            // pnlLoginTitel1
            // 
            this.pnlLoginTitel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(0)))), ((int)(((byte)(1)))));
            this.pnlLoginTitel1.ColumnCount = 1;
            this.pnlLoginTitel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlLoginTitel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.pnlLoginTitel1.Controls.Add(this.pnlLoginTitel2, 0, 0);
            this.pnlLoginTitel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLoginTitel1.Location = new System.Drawing.Point(3, 3);
            this.pnlLoginTitel1.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLoginTitel1.Name = "pnlLoginTitel1";
            this.pnlLoginTitel1.RowCount = 1;
            this.pnlLoginTitel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlLoginTitel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.pnlLoginTitel1.Size = new System.Drawing.Size(465, 113);
            this.pnlLoginTitel1.TabIndex = 0;
            // 
            // pnlLoginTitel2
            // 
            this.pnlLoginTitel2.ColumnCount = 1;
            this.pnlLoginTitel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlLoginTitel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.pnlLoginTitel2.Controls.Add(this.label2, 0, 0);
            this.pnlLoginTitel2.Controls.Add(this.lblLoginTitel2, 0, 1);
            this.pnlLoginTitel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLoginTitel2.Location = new System.Drawing.Point(2, 2);
            this.pnlLoginTitel2.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLoginTitel2.Name = "pnlLoginTitel2";
            this.pnlLoginTitel2.RowCount = 2;
            this.pnlLoginTitel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlLoginTitel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlLoginTitel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.pnlLoginTitel2.Size = new System.Drawing.Size(461, 109);
            this.pnlLoginTitel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Rockwell", 22.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(2, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(457, 54);
            this.label2.TabIndex = 2;
            this.label2.Text = "Vilm.kom";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLoginTitel2
            // 
            this.lblLoginTitel2.AutoSize = true;
            this.lblLoginTitel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLoginTitel2.Font = new System.Drawing.Font("Rockwell", 22.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoginTitel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblLoginTitel2.Location = new System.Drawing.Point(2, 54);
            this.lblLoginTitel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLoginTitel2.Name = "lblLoginTitel2";
            this.lblLoginTitel2.Size = new System.Drawing.Size(457, 55);
            this.lblLoginTitel2.TabIndex = 1;
            this.lblLoginTitel2.Text = "Inloggen";
            this.lblLoginTitel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlLoginInfo
            // 
            this.pnlLoginInfo.ColumnCount = 1;
            this.pnlLoginInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlLoginInfo.Controls.Add(this.pictureBox1, 0, 0);
            this.pnlLoginInfo.Controls.Add(this.pnlEmail, 0, 1);
            this.pnlLoginInfo.Controls.Add(this.pnlWachtwoord, 0, 3);
            this.pnlLoginInfo.Controls.Add(this.pnlButton, 0, 5);
            this.pnlLoginInfo.Controls.Add(this.lblErrorMessage, 0, 2);
            this.pnlLoginInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLoginInfo.Location = new System.Drawing.Point(3, 121);
            this.pnlLoginInfo.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLoginInfo.Name = "pnlLoginInfo";
            this.pnlLoginInfo.RowCount = 7;
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.pnlLoginInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.pnlLoginInfo.Size = new System.Drawing.Size(465, 535);
            this.pnlLoginInfo.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(461, 72);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pnlEmail
            // 
            this.pnlEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(2)))), ((int)(((byte)(5)))));
            this.pnlEmail.ColumnCount = 3;
            this.pnlEmail.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.pnlEmail.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.pnlEmail.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.pnlEmail.Controls.Add(this.txtGebruikersnaam, 1, 1);
            this.pnlEmail.Controls.Add(this.label1, 1, 0);
            this.pnlEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlEmail.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.pnlEmail.Location = new System.Drawing.Point(2, 78);
            this.pnlEmail.Margin = new System.Windows.Forms.Padding(2);
            this.pnlEmail.Name = "pnlEmail";
            this.pnlEmail.RowCount = 2;
            this.pnlEmail.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.pnlEmail.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.pnlEmail.Size = new System.Drawing.Size(461, 72);
            this.pnlEmail.TabIndex = 1;
            // 
            // txtGebruikersnaam
            // 
            this.txtGebruikersnaam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGebruikersnaam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGebruikersnaam.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGebruikersnaam.Location = new System.Drawing.Point(48, 23);
            this.txtGebruikersnaam.Margin = new System.Windows.Forms.Padding(2);
            this.txtGebruikersnaam.Multiline = true;
            this.txtGebruikersnaam.Name = "txtGebruikersnaam";
            this.txtGebruikersnaam.Size = new System.Drawing.Size(364, 47);
            this.txtGebruikersnaam.TabIndex = 0;
            this.txtGebruikersnaam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(49, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(362, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Gebruikersnaam:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlWachtwoord
            // 
            this.pnlWachtwoord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(2)))), ((int)(((byte)(5)))));
            this.pnlWachtwoord.ColumnCount = 3;
            this.pnlWachtwoord.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.pnlWachtwoord.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.pnlWachtwoord.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.pnlWachtwoord.Controls.Add(this.txtWachtwoord, 1, 1);
            this.pnlWachtwoord.Controls.Add(this.label3, 1, 0);
            this.pnlWachtwoord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlWachtwoord.Location = new System.Drawing.Point(2, 230);
            this.pnlWachtwoord.Margin = new System.Windows.Forms.Padding(2);
            this.pnlWachtwoord.Name = "pnlWachtwoord";
            this.pnlWachtwoord.RowCount = 2;
            this.pnlWachtwoord.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.pnlWachtwoord.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.pnlWachtwoord.Size = new System.Drawing.Size(461, 72);
            this.pnlWachtwoord.TabIndex = 2;
            // 
            // txtWachtwoord
            // 
            this.txtWachtwoord.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWachtwoord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWachtwoord.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWachtwoord.Location = new System.Drawing.Point(48, 23);
            this.txtWachtwoord.Margin = new System.Windows.Forms.Padding(2);
            this.txtWachtwoord.Multiline = true;
            this.txtWachtwoord.Name = "txtWachtwoord";
            this.txtWachtwoord.PasswordChar = '*';
            this.txtWachtwoord.Size = new System.Drawing.Size(364, 47);
            this.txtWachtwoord.TabIndex = 2;
            this.txtWachtwoord.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Rockwell", 14.25F);
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(49, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(362, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "Wachtwoord:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlButton
            // 
            this.pnlButton.ColumnCount = 3;
            this.pnlButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.pnlButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlButton.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.pnlButton.Controls.Add(this.btnLogin, 1, 1);
            this.pnlButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton.Location = new System.Drawing.Point(2, 382);
            this.pnlButton.Margin = new System.Windows.Forms.Padding(2);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.RowCount = 3;
            this.pnlButton.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.pnlButton.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.pnlButton.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.pnlButton.Size = new System.Drawing.Size(461, 72);
            this.pnlButton.TabIndex = 5;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(0)))), ((int)(((byte)(1)))));
            this.btnLogin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLogin.Font = new System.Drawing.Font("Rockwell", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnLogin.Location = new System.Drawing.Point(117, 12);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(226, 46);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            // 
            // lblErrorMessage
            // 
            this.lblErrorMessage.AutoSize = true;
            this.lblErrorMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblErrorMessage.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            this.lblErrorMessage.Location = new System.Drawing.Point(3, 152);
            this.lblErrorMessage.Name = "lblErrorMessage";
            this.lblErrorMessage.Size = new System.Drawing.Size(459, 76);
            this.lblErrorMessage.TabIndex = 8;
            this.lblErrorMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1426, 839);
            this.Controls.Add(this.pnlLoginMain);
            this.Name = "frmLogin";
            this.Text = "Login-Vilm.kom";
            this.pnlLoginMain.ResumeLayout(false);
            this.pnlLoginSecundary.ResumeLayout(false);
            this.pnlLoginTitel1.ResumeLayout(false);
            this.pnlLoginTitel2.ResumeLayout(false);
            this.pnlLoginTitel2.PerformLayout();
            this.pnlLoginInfo.ResumeLayout(false);
            this.pnlLoginInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlEmail.ResumeLayout(false);
            this.pnlEmail.PerformLayout();
            this.pnlWachtwoord.ResumeLayout(false);
            this.pnlWachtwoord.PerformLayout();
            this.pnlButton.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel pnlLoginMain;
        private System.Windows.Forms.TableLayoutPanel pnlLoginSecundary;
        private System.Windows.Forms.TableLayoutPanel pnlLoginTitel1;
        private System.Windows.Forms.TableLayoutPanel pnlLoginTitel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblLoginTitel2;
        private System.Windows.Forms.TableLayoutPanel pnlLoginInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel pnlEmail;
        private System.Windows.Forms.TextBox txtGebruikersnaam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel pnlWachtwoord;
        private System.Windows.Forms.TextBox txtWachtwoord;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel pnlButton;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblErrorMessage;
    }
}

